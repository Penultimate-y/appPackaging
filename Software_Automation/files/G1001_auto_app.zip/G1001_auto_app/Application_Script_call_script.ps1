##================================================
## MARK: Orchestrator Parameters
##================================================
[CmdletBinding()]
Param(
    # Path to a JSON config file. If supplied, values are loaded from disk.
    # Missing fields fall back to interactive prompts.
    [Parameter()]
    [string]$ConfigFile,

    # Skip the Y/N confirmation summary. Useful for unattended runs from config.
    [Parameter()]
    [switch]$NoConfirm,

    # After collecting inputs, save them to this path as a reusable JSON config.
    [Parameter()]
    [string]$SaveConfig
)

# Orchestrator version (recorded in the manifest)
$script:OrchestratorVersion = '1.0.0'

##================================================
## MARK: Utility Functions
##================================================
function Test-ExitRequest {
    param([string]$Value)
    return $Value -match '^(exit|quit|cancel)$'
}

##================================================
## MARK: Error Code Chart
##================================================
function Show-MsiExitCodeReference {
    Write-Host ""
    Write-Host "Standard MSI Exit Codes (from msiexec.exe):" -ForegroundColor Cyan
    Write-Host "-------------------------------------------"
    Write-Host "  0    - ERROR_SUCCESS                     : Action completed successfully"
    Write-Host "  1602 - ERROR_INSTALL_USEREXIT            : User cancelled installation"
    Write-Host "  1603 - ERROR_INSTALL_FAILURE             : Fatal error during installation"
    Write-Host "  1605 - ERROR_UNKNOWN_PRODUCT             : Product is not installed (uninstall)"
    Write-Host "  1618 - ERROR_INSTALL_ALREADY_RUNNING     : Another install in progress (retry)"
    Write-Host "  1619 - ERROR_INSTALL_PACKAGE_OPEN_FAILED : Installation package could not be opened"
    Write-Host "  1620 - ERROR_INSTALL_PACKAGE_INVALID     : Installation package is invalid"
    Write-Host "  1633 - ERROR_INSTALL_PLATFORM_UNSUPPORTED: Platform not supported"
    Write-Host "  1638 - ERROR_PRODUCT_VERSION             : Another version already installed"
    Write-Host "  1641 - ERROR_SUCCESS_REBOOT_INITIATED    : Success, hard reboot initiated"
    Write-Host "  3010 - ERROR_SUCCESS_REBOOT_REQUIRED     : Success, soft reboot required"
    Write-Host "-------------------------------------------"
    Write-Host ""
}

function Show-ExeExitCodeSuggestions {
    Write-Host ""
    Write-Host "Suggested EXE Exit Codes (vendor-specific — confirm with installer documentation):" -ForegroundColor Cyan
    Write-Host "-----------------------------------------------------------------------------------"
    Write-Host "  0    - Success (most common convention)"
    Write-Host "  1    - Generic failure (treat as non-success unless vendor docs say otherwise)"
    Write-Host "  3010 - Success, soft reboot required"
    Write-Host "  1618 - Another install in progress (retry)"
    Write-Host "-----------------------------------------------------------------------------------"
    Write-Host ""
}

##================================================
## MARK: Config File Support
##================================================
function Import-DeploymentConfig {
    <#
        Load a JSON config file and return a hashtable of its values.
        Validates the file exists and parses cleanly. Field-level validation
        happens later when each value is consumed by the prompt logic.
    #>
    param([Parameter(Mandatory)] [string]$Path)

    if (-not (Test-Path -Path $Path)) {
        throw "Config file not found: $Path"
    }

    try {
        $raw = Get-Content -Path $Path -Raw -ErrorAction Stop
        $obj = $raw | ConvertFrom-Json -ErrorAction Stop
    }
    catch {
        throw "Failed to parse config file '$Path': $_"
    }

    # Convert the PSCustomObject from ConvertFrom-Json into a hashtable
    # so we can use ContainsKey() checks naturally.
    $hash = @{}
    foreach ($prop in $obj.PSObject.Properties) {
        $hash[$prop.Name] = $prop.Value
    }
    return $hash
}

function Get-ConfigValue {
    <#
        Pull a value from the config hashtable if present and non-null/non-empty.
        Returns $null if the key is missing or the value is empty — caller treats
        $null as "fall through to interactive prompt".
    #>
    param(
        [Parameter(Mandatory)] [hashtable]$Config,
        [Parameter(Mandatory)] [string]$Key
    )
    if (-not $Config.ContainsKey($Key)) { return $null }
    $v = $Config[$Key]
    if ($null -eq $v) { return $null }
    if ($v -is [string] -and [string]::IsNullOrWhiteSpace($v)) { return $null }
    return $v
}

function Save-DeploymentConfig {
    <#
        Serialize the collected $userInput object to a JSON config file the
        user can edit and re-feed via -ConfigFile.
    #>
    param(
        [Parameter(Mandatory)] [PSCustomObject]$UserInput,
        [Parameter(Mandatory)] [string]$Path
    )

    # Build a clean object with only the fields a config file should contain.
    # Derived/computed fields (CombinedSuccessCodes, FilledCategories, EmptyCategories)
    # are recomputed at runtime, so they are deliberately excluded.
    $configObject = [ordered]@{
        AppName         = $UserInput.AppName
        PackageName     = $UserInput.PackageName
        AppVersion      = $UserInput.AppVersion
        DeploymentType  = $UserInput.DeploymentType
        InstallerType   = $UserInput.InstallerType
        InstallerName   = $UserInput.InstallerName
        Arguments       = $UserInput.Arguments
        ProcessesToStop = @($UserInput.ProcessesToStop)
        DetectionPath   = $UserInput.DetectionPath
        SuccessCodes    = @($UserInput.SuccessCodes)
        SoftRebootCodes = @($UserInput.SoftRebootCodes)
        HardRebootCodes = @($UserInput.HardRebootCodes)
        RetryCodes      = @($UserInput.RetryCodes)
    }

    $json = $configObject | ConvertTo-Json -Depth 5

    # Ensure parent directory exists
    $parent = Split-Path -Parent $Path
    if ($parent -and -not (Test-Path -Path $parent)) {
        New-Item -Path $parent -ItemType Directory -Force | Out-Null
    }

    $json | Out-File -FilePath $Path -Encoding UTF8 -Force
    Write-Host "Config saved to: $Path" -ForegroundColor Green
}

##================================================
## MARK: Manifest Generation
##================================================
function Get-FileSha256 {
    param([Parameter(Mandatory)] [string]$Path)
    if (-not (Test-Path -Path $Path)) { return $null }
    return (Get-FileHash -Path $Path -Algorithm SHA256).Hash
}

function New-DeploymentManifest {
    <#
        Build a manifest object describing this deployment generation.
        Returns a PSCustomObject ready to be written to JSON.
    #>
    param(
        [Parameter(Mandatory)] [PSCustomObject]$UserInput,
        [Parameter(Mandatory)] [string]$GeneratedScriptPath,
        [Parameter()]          [string]$ConfigFilePath,
        [Parameter()]          [string]$InputSource = 'Interactive'
    )

    $now = Get-Date
    $hash = Get-FileSha256 -Path $GeneratedScriptPath
    $size = if (Test-Path -Path $GeneratedScriptPath) {
        (Get-Item -Path $GeneratedScriptPath).Length
    } else { 0 }

    $manifest = [ordered]@{
        Generation = [ordered]@{
            TimestampUtc        = $now.ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
            TimestampLocal      = $now.ToString('yyyy-MM-dd HH:mm:ss zzz')
            GeneratedBy         = "$env:USERDOMAIN\$env:USERNAME"
            GeneratedOn         = $env:COMPUTERNAME
            OrchestratorVersion = $script:OrchestratorVersion
            PowerShellVersion   = $PSVersionTable.PSVersion.ToString()
            OsVersion           = [System.Environment]::OSVersion.VersionString
            InputSource         = $InputSource
            ConfigFilePath      = $ConfigFilePath
        }
        Inputs = [ordered]@{
            AppName              = $UserInput.AppName
            PackageName          = $UserInput.PackageName
            AppVersion           = $UserInput.AppVersion
            DeploymentType       = $UserInput.DeploymentType
            InstallerType        = $UserInput.InstallerType
            InstallerName        = $UserInput.InstallerName
            Arguments            = $UserInput.Arguments
            ProcessesToStop      = @($UserInput.ProcessesToStop)
            DetectionPath        = $UserInput.DetectionPath
            SuccessCodes         = @($UserInput.SuccessCodes)
            SoftRebootCodes      = @($UserInput.SoftRebootCodes)
            HardRebootCodes      = @($UserInput.HardRebootCodes)
            RetryCodes           = @($UserInput.RetryCodes)
            CombinedSuccessCodes = @($UserInput.CombinedSuccessCodes)
        }
        GeneratedScript = [ordered]@{
            Path      = $GeneratedScriptPath
            Sha256    = $hash
            SizeBytes = $size
        }
        Execution = [ordered]@{
            Executed         = $false
            ExitCode         = $null
            DurationSeconds  = $null
            TimestampUtc     = $null
        }
    }

    return [PSCustomObject]$manifest
}

function Write-DeploymentManifest {
    <#
        Write the manifest to two places:
          1. A per-generation .json file alongside the .ps1
          2. Append a single-line record to manifest_log.jsonl in the Generated/ folder
    #>
    param(
        [Parameter(Mandatory)] [PSCustomObject]$Manifest,
        [Parameter(Mandatory)] [string]$GeneratedScriptPath,
        [Parameter(Mandatory)] [string]$OutputDirectory
    )

    # Per-generation file (same base name as the .ps1 but with .json)
    $perGenPath = [System.IO.Path]::ChangeExtension($GeneratedScriptPath, '.json')
    $Manifest | ConvertTo-Json -Depth 8 | Out-File -FilePath $perGenPath -Encoding UTF8 -Force
    Write-Host "Per-deployment manifest: $perGenPath" -ForegroundColor Cyan

    # Rolling JSONL log (one record per line, append-only)
    $rollingPath = Join-Path $OutputDirectory 'manifest_log.jsonl'
    $singleLine = $Manifest | ConvertTo-Json -Depth 8 -Compress
    Add-Content -Path $rollingPath -Value $singleLine -Encoding UTF8
    Write-Host "Rolling manifest log:    $rollingPath" -ForegroundColor Cyan

    return $perGenPath
}

function Update-ManifestExecution {
    <#
        After running the generated script, update the per-generation manifest
        with execution results. The rolling log gets a second record appended
        so you can trace the full lifecycle (generate -> run -> result).
    #>
    param(
        [Parameter(Mandatory)] [string]$ManifestPath,
        [Parameter(Mandatory)] [string]$RollingLogPath,
        [Parameter(Mandatory)] [bool]$Executed,
        [Parameter()]          [int]$ExitCode = 0,
        [Parameter()]          [double]$DurationSeconds = 0
    )

    if (-not (Test-Path -Path $ManifestPath)) {
        Write-Host "WARNING: Manifest not found at $ManifestPath; cannot update execution result." -ForegroundColor Yellow
        return
    }

    $manifest = Get-Content -Path $ManifestPath -Raw | ConvertFrom-Json

    $manifest.Execution.Executed        = $Executed
    $manifest.Execution.ExitCode        = $ExitCode
    $manifest.Execution.DurationSeconds = $DurationSeconds
    $manifest.Execution.TimestampUtc    = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')

    $manifest | ConvertTo-Json -Depth 8 | Out-File -FilePath $ManifestPath -Encoding UTF8 -Force

    # Append the updated record to the rolling log too
    $singleLine = $manifest | ConvertTo-Json -Depth 8 -Compress
    Add-Content -Path $RollingLogPath -Value $singleLine -Encoding UTF8
}

##================================================
## MARK: Exit Code Reader (used by both interactive and config paths)
##================================================
function Read-CategoryOrNone {
    param([string]$Label, [string]$Default)
    while ($true) {
        $effectiveDefault = if ([string]::IsNullOrWhiteSpace($Default)) { '<none>' } else { $Default }
        $raw = Read-Host -Prompt "$Label [default: $effectiveDefault] (or 'exit' to cancel)"
        if (Test-ExitRequest $raw) { $script:exitRequested = $true; return $null }
        if ($raw -match '^(?i)none$') { return ,@() }
        if ([string]::IsNullOrWhiteSpace($raw)) {
            if ([string]::IsNullOrWhiteSpace($Default)) { return ,@() }
            $raw = $Default
        }
        $tokens = $raw -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' }
        $parsed = @()
        $allValid = $true
        foreach ($tok in $tokens) {
            $n = 0
            if ([int]::TryParse($tok, [ref]$n)) { $parsed += $n }
            else {
                Write-Host "Invalid exit code '$tok'. Must be an integer." -ForegroundColor Yellow
                $allValid = $false; break
            }
        }
        if (-not $allValid) { continue }
        $unique = @()
        foreach ($n in $parsed) { if ($unique -notcontains $n) { $unique += $n } }
        return ,$unique
    }
}

function Resolve-ExitCodes {
    <#
        Resolve a single exit-code category. If config provides the key, validate
        and return its value. Otherwise fall through to interactive prompt.
    #>
    param(
        [Parameter(Mandatory)] [string]$ConfigKey,
        [Parameter(Mandatory)] [string]$Label,
        [Parameter()]          [string]$Default,
        [Parameter(Mandatory)] [hashtable]$Cfg
    )
    if ($Cfg.ContainsKey($ConfigKey)) {
        $raw = $Cfg[$ConfigKey]
        if ($null -eq $raw) { return ,@() }
        $arr = @($raw)
        $out = @()
        foreach ($n in $arr) {
            $i = 0
            if (-not [int]::TryParse([string]$n, [ref]$i)) {
                throw "Config error: '$ConfigKey' contains non-integer value '$n'."
            }
            if ($out -notcontains $i) { $out += $i }
        }
        Write-Host "$Label (from config) : $($out -join ', ')" -ForegroundColor DarkCyan
        return ,$out
    }
    return ,(Read-CategoryOrNone -Label $Label -Default $Default)
}

##================================================
## MARK: User Input Functions
##================================================
function Get-UserInput {
    param(
        [Parameter()] [hashtable]$Config = @{},
        [Parameter()] [switch]$NoConfirm
    )

    $script:exitRequested = $false
    $usingConfig = ($Config.Count -gt 0)

    if ($usingConfig) {
        Write-Host ""
        Write-Host "Loaded $($Config.Count) field(s) from config file." -ForegroundColor Cyan
        Write-Host "Missing fields will be prompted interactively." -ForegroundColor Cyan
        Write-Host ""
    }

    do {
        # ----- Application Name -----
        $appName = Get-ConfigValue -Config $Config -Key 'AppName'
        if ($null -eq $appName) {
            do {
                $appName = Read-Host -Prompt "Application Name (or type 'exit' to cancel)"
                if (Test-ExitRequest $appName) { $script:exitRequested = $true; break }
                if ([string]::IsNullOrWhiteSpace($appName)) {
                    Write-Host "Application Name cannot be empty. Please try again." -ForegroundColor Yellow
                }
            } while ([string]::IsNullOrWhiteSpace($appName))
        }
        else {
            Write-Host "Application Name (from config)   : $appName" -ForegroundColor DarkCyan
        }
        if ($script:exitRequested) { break }

        # ----- Package Folder Name -----
        $packageName = Get-ConfigValue -Config $Config -Key 'PackageName'
        if ($null -eq $packageName) {
            do {
                $packageName = Read-Host -Prompt "Application Package folder name (or 'exit' to cancel)"
                if (Test-ExitRequest $packageName) { $script:exitRequested = $true; break }
                if ([string]::IsNullOrWhiteSpace($packageName)) {
                    Write-Host "Package folder name cannot be empty. Please try again." -ForegroundColor Yellow
                }
            } while ([string]::IsNullOrWhiteSpace($packageName))
        }
        else {
            Write-Host "Package Folder Name (from config): $packageName" -ForegroundColor DarkCyan
        }
        if ($script:exitRequested) { break }

        # ----- Application Version (validated x.x.x.x) -----
        $versionRegex = '^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$'
        $appVersion = Get-ConfigValue -Config $Config -Key 'AppVersion'
        if ($null -ne $appVersion) {
            if ($appVersion -notmatch $versionRegex) {
                throw "Config error: AppVersion '$appVersion' is not in valid x.x.x.x format."
            }
            Write-Host "Application Version (from config): $appVersion" -ForegroundColor DarkCyan
        }
        else {
            do {
                $appVersion = Read-Host -Prompt "Application Version (format x.x.x.x, e.g. 1.2.3.4 up to 999.999.999.999) (or 'exit' to cancel)"
                if (Test-ExitRequest $appVersion) { $script:exitRequested = $true; break }
                if ($appVersion -notmatch $versionRegex) {
                    Write-Host "Invalid version format. Must be four numeric segments separated by dots, each 1-3 digits." -ForegroundColor Yellow
                    $appVersion = $null
                }
            } while ([string]::IsNullOrWhiteSpace($appVersion))
        }
        if ($script:exitRequested) { break }

        # ----- Deployment Type (validated) -----
        $validDeploymentTypes = @('Install', 'Uninstall')
        $deploymentType = Get-ConfigValue -Config $Config -Key 'DeploymentType'
        if ($null -ne $deploymentType) {
            $match = $validDeploymentTypes | Where-Object { $_ -ieq $deploymentType }
            if (-not $match) {
                throw "Config error: DeploymentType '$deploymentType' must be 'Install' or 'Uninstall'."
            }
            $deploymentType = $match
            Write-Host "Deployment Type (from config)    : $deploymentType" -ForegroundColor DarkCyan
        }
        else {
            do {
                $deploymentType = Read-Host -Prompt "Deployment Type (Install or Uninstall) (or 'exit' to cancel)"
                if (Test-ExitRequest $deploymentType) { $script:exitRequested = $true; break }
                $deploymentTypeMatch = $validDeploymentTypes | Where-Object { $_ -ieq $deploymentType }
                if (-not $deploymentTypeMatch) {
                    Write-Host "Invalid entry. Please type 'Install' or 'Uninstall'." -ForegroundColor Yellow
                }
                else { $deploymentType = $deploymentTypeMatch }
            } while (-not $deploymentTypeMatch)
        }
        if ($script:exitRequested) { break }

        # ----- Installer Type (validated) -----
        $validInstallerTypes = @('MSI', 'EXE')
        $installerType = Get-ConfigValue -Config $Config -Key 'InstallerType'
        if ($null -ne $installerType) {
            $match = $validInstallerTypes | Where-Object { $_ -ieq $installerType }
            if (-not $match) {
                throw "Config error: InstallerType '$installerType' must be 'MSI' or 'EXE'."
            }
            $installerType = $match
            Write-Host "Installer Type (from config)     : $installerType" -ForegroundColor DarkCyan
        }
        else {
            do {
                $installerType = Read-Host -Prompt "Installer Type (MSI or EXE) (or 'exit' to cancel)"
                if (Test-ExitRequest $installerType) { $script:exitRequested = $true; break }
                $installerTypeMatch = $validInstallerTypes | Where-Object { $_ -ieq $installerType }
                if (-not $installerTypeMatch) {
                    Write-Host "Invalid entry. Please type 'MSI' or 'EXE'." -ForegroundColor Yellow
                }
                else { $installerType = $installerTypeMatch }
            } while (-not $installerTypeMatch)
        }
        if ($script:exitRequested) { break }

        # ----- Installer File Name (extension must match installer type) -----
        $installerName = Get-ConfigValue -Config $Config -Key 'InstallerName'
        if ($null -ne $installerName) {
            $extension = [System.IO.Path]::GetExtension($installerName).TrimStart('.').ToUpper()
            if ($extension -ne $installerType) {
                throw "Config error: InstallerName '$installerName' extension does not match InstallerType '$installerType'."
            }
            Write-Host "Installer File Name (from config): $installerName" -ForegroundColor DarkCyan
        }
        else {
            do {
                $installerName = Read-Host -Prompt "Installer file name (must end in .$installerType, e.g. setup.$($installerType.ToLower())) (or 'exit' to cancel)"
                if (Test-ExitRequest $installerName) { $script:exitRequested = $true; break }
                if ([string]::IsNullOrWhiteSpace($installerName)) {
                    Write-Host "Installer file name cannot be empty. Please try again." -ForegroundColor Yellow
                    continue
                }
                $extension = [System.IO.Path]::GetExtension($installerName).TrimStart('.').ToUpper()
                if ($extension -ne $installerType) {
                    Write-Host "Installer file name must end with .$installerType to match the selected installer type. You entered: '$installerName'" -ForegroundColor Yellow
                    $installerName = $null
                }
            } while ([string]::IsNullOrWhiteSpace($installerName))
        }
        if ($script:exitRequested) { break }

        # ----- Arguments (optional, can be empty string) -----
        # Note: ContainsKey check (not Get-ConfigValue) so empty-string in config
        # is honored as "explicitly no arguments" rather than "missing".
        if ($Config.ContainsKey('Arguments')) {
            $arguments = if ($null -eq $Config['Arguments']) { '' } else { [string]$Config['Arguments'] }
            Write-Host "Arguments (from config)          : $(if ($arguments) { $arguments } else { '<none>' })" -ForegroundColor DarkCyan
        }
        else {
            if ($installerType -eq 'MSI') {
                $argHint = "e.g. /qn /norestart ALLUSERS=1"
            }
            else {
                $argHint = "e.g. /S or /silent (vendor-specific)"
            }
            $arguments = Read-Host -Prompt "Arguments ($argHint, leave blank if none, or 'exit' to cancel)"
            if (Test-ExitRequest $arguments) { $script:exitRequested = $true; break }
        }
        if ($script:exitRequested) { break }

        ##================================================
        ## MARK: Processes to Stop
        ##================================================
        if ($Config.ContainsKey('ProcessesToStop')) {
            $raw = $Config['ProcessesToStop']
            if ($null -eq $raw) {
                $processesToStop = @()
            }
            else {
                $processesToStop = @($raw) | ForEach-Object { ($_ -replace '\.exe$', '').Trim() } | Where-Object { $_ -ne '' }
                # De-duplicate while preserving order
                $deduped = @()
                foreach ($p in $processesToStop) { if ($deduped -notcontains $p) { $deduped += $p } }
                $processesToStop = $deduped
            }
            Write-Host "Processes to Stop (from config)  : $(if ($processesToStop.Count) { $processesToStop -join ', ' } else { '<none>' })" -ForegroundColor DarkCyan
        }
        else {
            Write-Host ""
            Write-Host "Processes to stop before $deploymentType (optional):" -ForegroundColor Cyan
            Write-Host "  Enter one or more process names (without .exe), comma-separated." -ForegroundColor DarkGray
            Write-Host "  Examples: 'Zoom' or 'chrome, msedge, firefox' or 'AcroRd32, Acrobat'" -ForegroundColor DarkGray
            Write-Host "  Leave blank to skip, or type 'none' for no processes." -ForegroundColor DarkGray

            $processNameRegex = '^[A-Za-z0-9_\-\.\s]+$'
            do {
                $processRaw = Read-Host -Prompt "Processes to stop (or 'exit' to cancel)"
                if (Test-ExitRequest $processRaw) { $script:exitRequested = $true; break }

                if ([string]::IsNullOrWhiteSpace($processRaw) -or $processRaw -match '^(?i)none$') {
                    $processesToStop = @()
                    break
                }

                $procTokens = $processRaw -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' }
                $procParsed = @()
                $allValid = $true
                foreach ($p in $procTokens) {
                    $cleaned = $p -replace '\.exe$', ''
                    if ($cleaned -notmatch $processNameRegex) {
                        Write-Host "Invalid process name '$p'. Use only letters, digits, hyphens, underscores, or dots." -ForegroundColor Yellow
                        $allValid = $false
                        break
                    }
                    if ($procParsed -notcontains $cleaned) { $procParsed += $cleaned }
                }
                if (-not $allValid) { continue }
                $processesToStop = $procParsed
                break
            } while ($true)
        }
        if ($script:exitRequested) { break }

        ##================================================
        ## MARK: Detection Path
        ##================================================
        if ($Config.ContainsKey('DetectionPath')) {
            $detectionPath = if ($null -eq $Config['DetectionPath']) { '' } 
        else{ 
            [string]$Config['DetectionPath']
        }
            if ($detectionPath -ne '') {
                $hasDriveLetter = $detectionPath -match '^[A-Za-z]:\\'
                $isUnc          = $detectionPath -match '^\\\\[^\\]+\\[^\\]+'
                $hasBadChars    = $detectionPath -match '[<>"|\?\*]'
                if (-not ($hasDriveLetter -or $isUnc) -or $hasBadChars) {
                    throw "Config error: DetectionPath '$detectionPath' is not a valid path. Must start with drive letter or UNC, no <>|?* characters."
                }
            }
        Write-Host "Detection Path (from config)     : $(if ($detectionPath) { $detectionPath } else { '<none>' })" -ForegroundColor DarkCyan
        }
        else {
            Write-Host ""
            Write-Host "Detection path (optional):" -ForegroundColor Cyan
            Write-Host "  Full path to a file or folder that should exist after a successful install." -ForegroundColor DarkGray
            Write-Host "  Used as a sanity check in addition to exit code evaluation." -ForegroundColor DarkGray
            Write-Host "  Examples: 'C:\Program Files\Acme\App.exe' or 'C:\ProgramData\Acme'" -ForegroundColor DarkGray
            Write-Host "  Leave blank to skip detection." -ForegroundColor DarkGray

            do {
                $detectionPath = Read-Host -Prompt "Detection path (or 'exit' to cancel)"
                if (Test-ExitRequest $detectionPath) { $script:exitRequested = $true; break }

                if ([string]::IsNullOrWhiteSpace($detectionPath)) {
                    $detectionPath = ''
                    break
                }

                $hasDriveLetter = $detectionPath -match '^[A-Za-z]:\\'
                $isUnc          = $detectionPath -match '^\\\\[^\\]+\\[^\\]+'
                $hasBadChars    = $detectionPath -match '[<>"|\?\*]'

                if (-not ($hasDriveLetter -or $isUnc)) {
                    Write-Host "Invalid path. Must start with a drive letter (e.g. C:\) or UNC path (e.g. \\server\share)." -ForegroundColor Yellow
                    $detectionPath = $null
                    continue
                }
                if ($hasBadChars) {
                    Write-Host "Path contains invalid characters. Avoid: < > `" | ? *" -ForegroundColor Yellow
                    $detectionPath = $null
                    continue
                }
                break
            } while ($true)
        }
        if ($script:exitRequested) { break }

        ##================================================
        ## MARK: Exit Code Prompts
        ##================================================
        # Show the appropriate reference chart only if we'll be prompting for at
        # least one exit-code category interactively. If config supplies all four,
        # the chart is just visual noise.
        $needCodePrompts = -not (
            $Config.ContainsKey('SuccessCodes') -and
            $Config.ContainsKey('SoftRebootCodes') -and
            $Config.ContainsKey('HardRebootCodes') -and
            $Config.ContainsKey('RetryCodes')
        )

        if ($installerType -eq 'MSI') {
            if ($needCodePrompts) { Show-MsiExitCodeReference }
            $defaultSuccess    = '0'
            $defaultSoftReboot = '3010'
            $defaultHardReboot = '1641'
            $defaultRetry      = '1618'
        }
        else {
            if ($needCodePrompts) { Show-ExeExitCodeSuggestions }
            $defaultSuccess    = '0'
            $defaultSoftReboot = '3010'
            $defaultHardReboot = ''
            $defaultRetry      = '1618'
        }

        if ($needCodePrompts) {
            Write-Host "Enter exit codes as comma-separated integers. Press Enter to accept the default." -ForegroundColor Cyan
            Write-Host "Type 'none' to leave a category empty." -ForegroundColor DarkGray
            Write-Host "Note: Soft and hard reboot codes are treated as successful installs." -ForegroundColor DarkGray
            Write-Host ""
        }

        $successCodes = Resolve-ExitCodes -ConfigKey 'SuccessCodes' -Label "Success exit codes" -Default $defaultSuccess -Cfg $Config
        if ($script:exitRequested) { break }

        $softRebootCodes = Resolve-ExitCodes -ConfigKey 'SoftRebootCodes' -Label "Soft reboot exit codes" -Default $defaultSoftReboot -Cfg $Config
        if ($script:exitRequested) { break }

        $hardRebootCodes = Resolve-ExitCodes -ConfigKey 'HardRebootCodes' -Label "Hard reboot exit codes" -Default $defaultHardReboot -Cfg $Config
        if ($script:exitRequested) { break }

        $retryCodes = Resolve-ExitCodes -ConfigKey 'RetryCodes' -Label "Retry exit codes" -Default $defaultRetry -Cfg $Config
        if ($script:exitRequested) { break }

        ##================================================
        ## MARK: Filled/Empty Codes
        ##================================================
        $filledCategories = @()
        $emptyCategories  = @()
        if ($successCodes    -and $successCodes.Count    -gt 0) { $filledCategories += 'Success' }    else { $emptyCategories += 'Success' }
        if ($softRebootCodes -and $softRebootCodes.Count -gt 0) { $filledCategories += 'SoftReboot' } else { $emptyCategories += 'SoftReboot' }
        if ($hardRebootCodes -and $hardRebootCodes.Count -gt 0) { $filledCategories += 'HardReboot' } else { $emptyCategories += 'HardReboot' }
        if ($retryCodes      -and $retryCodes.Count      -gt 0) { $filledCategories += 'Retry' }      else { $emptyCategories += 'Retry' }

        # Merge Success ∪ SoftReboot ∪ HardReboot into a single combined success list
        # (Retry stays separate — it is NOT a success outcome)
        $combinedSuccessCodes = @()
        foreach ($n in $successCodes)    { if ($combinedSuccessCodes -notcontains $n) { $combinedSuccessCodes += $n } }
        foreach ($n in $softRebootCodes) { if ($combinedSuccessCodes -notcontains $n) { $combinedSuccessCodes += $n } }
        foreach ($n in $hardRebootCodes) { if ($combinedSuccessCodes -notcontains $n) { $combinedSuccessCodes += $n } }

        if ($combinedSuccessCodes.Count -eq 0) {
            Write-Host "WARNING: No success-equivalent codes were provided. Adding 0 as the default success code." -ForegroundColor Yellow
            $combinedSuccessCodes = @(0)
            if ($emptyCategories -contains 'Success') {
                $emptyCategories  = $emptyCategories  | Where-Object { $_ -ne 'Success' }
                $filledCategories += 'Success (auto)'
            }
        }

        $userInput = [PSCustomObject]@{
            AppName              = $appName
            PackageName          = $packageName
            AppVersion           = $appVersion
            DeploymentType       = $deploymentType
            InstallerType        = $installerType
            InstallerName        = $installerName
            Arguments            = $arguments
            ProcessesToStop      = $processesToStop
            DetectionPath        = $detectionPath
            SuccessCodes         = $successCodes
            SoftRebootCodes      = $softRebootCodes
            HardRebootCodes      = $hardRebootCodes
            RetryCodes           = $retryCodes
            CombinedSuccessCodes = $combinedSuccessCodes
            FilledCategories     = $filledCategories
            EmptyCategories      = $emptyCategories
        }

        ##================================================
        ## MARK: Confirmation Summary
        ##================================================
        Write-Host ""
        Write-Host "Please confirm the following selections:" -ForegroundColor Cyan
        Write-Host "----------------------------------------"
        Write-Host ("Application Name      : {0}" -f $userInput.AppName)
        Write-Host ("Package Folder Name   : {0}" -f $userInput.PackageName)
        Write-Host ("Application Version   : {0}" -f $userInput.AppVersion)
        Write-Host ("Deployment Type       : {0}" -f $userInput.DeploymentType)
        Write-Host ("Installer Type        : {0}" -f $userInput.InstallerType)
        Write-Host ("Installer File Name   : {0}" -f $userInput.InstallerName)
        Write-Host ("Arguments             : {0}" -f $(if ($userInput.Arguments) { $userInput.Arguments } else { '<none>' }))
        Write-Host ("Processes to Stop     : {0}" -f $(if ($userInput.ProcessesToStop.Count) { $userInput.ProcessesToStop -join ', ' } else { '<none>' }))
        Write-Host ("Detection Path        : {0}" -f $(if ($userInput.DetectionPath) { $userInput.DetectionPath } else { '<none>' }))
        Write-Host ""
        Write-Host "Exit code breakdown (raw input):" -ForegroundColor Cyan
        Write-Host ("  Success Codes       : {0}" -f $(if ($userInput.SuccessCodes.Count)    { $userInput.SuccessCodes    -join ', ' } else { '<none>' }))
        Write-Host ("  Soft Reboot Codes   : {0}" -f $(if ($userInput.SoftRebootCodes.Count) { $userInput.SoftRebootCodes -join ', ' } else { '<none>' }))
        Write-Host ("  Hard Reboot Codes   : {0}" -f $(if ($userInput.HardRebootCodes.Count) { $userInput.HardRebootCodes -join ', ' } else { '<none>' }))
        Write-Host ("  Retry Codes         : {0}" -f $(if ($userInput.RetryCodes.Count)      { $userInput.RetryCodes      -join ', ' } else { '<none>' }))
        Write-Host ""
        Write-Host "Categories filled : $($userInput.FilledCategories -join ', ')" -ForegroundColor Green
        if ($userInput.EmptyCategories.Count -gt 0) {
            Write-Host "Categories empty  : $($userInput.EmptyCategories -join ', ')" -ForegroundColor DarkGray
        }
        Write-Host ""
        Write-Host "Merged success list passed to target script (success + reboots):" -ForegroundColor Cyan
        Write-Host ("  -successCodes       : {0}" -f ($userInput.CombinedSuccessCodes -join ', '))
        Write-Host ("  -retryCodes         : {0}" -f $(if ($userInput.RetryCodes.Count) { $userInput.RetryCodes -join ', ' } else { '<none>' }))
        Write-Host "----------------------------------------"
        Write-Host ""

        ##================================================
        ## MARK: Confirmation Prompt (skipped under -NoConfirm)
        ##================================================
        if ($NoConfirm) {
            Write-Host "[-NoConfirm] Skipping confirmation prompt." -ForegroundColor DarkCyan
            $confirmed = $true
        }
        else {
            do {
                $confirmation = Read-Host "Are these values correct? (Y/N, or 'exit' to cancel)"
                if (Test-ExitRequest $confirmation) { $script:exitRequested = $true; break }
                if ($confirmation -notmatch '^(Y|y|Yes|yes|N|n|No|no)$') {
                    Write-Host "Please answer Y or N." -ForegroundColor Yellow
                }
            } while ($confirmation -notmatch '^(Y|y|Yes|yes|N|n|No|no)$')
            if ($script:exitRequested) { break }

            $confirmed = $confirmation -match '^(Y|y|Yes|yes)$'
            if (-not $confirmed) {
                Write-Host ""
                Write-Host "Let's try again..." -ForegroundColor Cyan
                Write-Host ""
                # Drop the config so the retry loop is fully interactive — otherwise
                # the user would be stuck re-confirming the same bad config forever.
                $Config = @{}
                $usingConfig = $false
            }
        }

    } while (-not $confirmed)

    if ($script:exitRequested) { return $null }
    return $userInput
}

##================================================
## MARK: Generate Standalone Script
##================================================
function ConvertTo-PsLiteral {
    <#
        Converts a PowerShell value into a source-code literal that, when pasted
        into a .ps1 file, recreates the original value. Handles strings, ints,
        and int arrays — which covers everything the orchestrator collects.
    #>
    param([Parameter()] $Value)

    if ($null -eq $Value) { return '$null' }

    if ($Value -is [System.Array]) {
        if ($Value.Count -eq 0) { return '@()' }
        $items = $Value | ForEach-Object { ConvertTo-PsLiteral $_ }
        return '@(' + ($items -join ', ') + ')'
    }

    if ($Value -is [int] -or $Value -is [long]) {
        return $Value.ToString()
    }

    $s = [string]$Value
    $escaped = $s -replace "'", "''"
    return "'$escaped'"
}

function Get-SafeFileNameSegment {
    param([string]$Value)
    if ([string]::IsNullOrWhiteSpace($Value)) { return 'unknown' }
    $cleaned = $Value -replace '[<>:"/\\|\?\*]', ''
    $cleaned = $cleaned -replace '\s+', '_'
    $cleaned = $cleaned.Trim('_', '.')
    if ([string]::IsNullOrWhiteSpace($cleaned)) { return 'unknown' }
    return $cleaned
}

function New-StandaloneDeploymentScript {
    <#
        Reads the parameterized template, strips its Param() block, injects the
        user's values as hardcoded variables, and saves the result as a new
        standalone .ps1 file. Returns the full path to the saved file.
    #>
    param(
        [Parameter(Mandatory)] [string]         $TemplatePath,
        [Parameter(Mandatory)] [string]         $OutputDirectory,
        [Parameter(Mandatory)] [PSCustomObject] $UserInput
    )

    if (-not (Test-Path -Path $TemplatePath)) {
        throw "Template script not found at: $TemplatePath"
    }

    $templateContent = Get-Content -Path $TemplatePath -Raw

    $paramBlockPattern = '(?ims)^\s*(\[CmdletBinding\(\)\]\s*)?Param\s*\((?:[^()]|\([^()]*\))*\)\s*'
    if ($templateContent -match $paramBlockPattern) {
        $templateContent = [System.Text.RegularExpressions.Regex]::Replace(
            $templateContent, $paramBlockPattern, '', 'IgnoreCase, Multiline, Singleline'
        )
    }
    else {
        Write-Host "WARNING: No Param() block found in template — values will be prepended without removal." -ForegroundColor Yellow
    }

    $generatedAt = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $valuesBlock = @"
##================================================
## MARK: Auto-Generated Hardcoded Values
##================================================
# Generated by orchestrator on $generatedAt
# Source template: $TemplatePath
# DO NOT EDIT BELOW — values are baked in from the orchestrator run.

`$applicationName = $(ConvertTo-PsLiteral $UserInput.AppName)
`$packageName     = $(ConvertTo-PsLiteral $UserInput.PackageName)
`$appVersion      = $(ConvertTo-PsLiteral $UserInput.AppVersion)
`$DeploymentType  = $(ConvertTo-PsLiteral $UserInput.DeploymentType)
`$installerType   = $(ConvertTo-PsLiteral $UserInput.InstallerType)
`$installerName   = $(ConvertTo-PsLiteral $UserInput.InstallerName)
`$arguments       = $(ConvertTo-PsLiteral $UserInput.Arguments)
`$successCodes    = $(ConvertTo-PsLiteral $UserInput.CombinedSuccessCodes)
`$retryCodes      = $(ConvertTo-PsLiteral $UserInput.RetryCodes)
`$processToStop   = $(ConvertTo-PsLiteral $UserInput.ProcessesToStop)
`$detectionPath   = $(ConvertTo-PsLiteral $UserInput.DetectionPath)

##================================================

"@

    $finalContent = $valuesBlock + $templateContent.TrimStart()

    $safeApp     = Get-SafeFileNameSegment $UserInput.AppName
    $safeVersion = Get-SafeFileNameSegment $UserInput.AppVersion
    $safeType    = Get-SafeFileNameSegment $UserInput.DeploymentType
    $baseName    = "Deploy_${safeApp}_${safeVersion}_${safeType}"
    $outputFile  = Join-Path $OutputDirectory "$baseName.ps1"

    if (Test-Path -Path $outputFile) {
        $timestamp  = Get-Date -Format 'yyyyMMdd_HHmmss'
        $outputFile = Join-Path $OutputDirectory "${baseName}_${timestamp}.ps1"
    }

    if (-not (Test-Path -Path $OutputDirectory)) {
        New-Item -Path $OutputDirectory -ItemType Directory -Force | Out-Null
    }

    $finalContent | Out-File -FilePath $outputFile -Encoding UTF8 -Force

    return $outputFile
}

##================================================
## MARK: Main Script Body
##================================================

# ----- Load config file if provided -----
$loadedConfig = @{}
$inputSource = 'Interactive'
if (-not [string]::IsNullOrWhiteSpace($ConfigFile)) {
    try {
        $loadedConfig = Import-DeploymentConfig -Path $ConfigFile
        $inputSource  = 'ConfigFile'
        Write-Host "Loaded config from: $ConfigFile" -ForegroundColor Green
    }
    catch {
        Write-Host "ERROR loading config: $_" -ForegroundColor Red
        return
    }
}

# ----- Collect (or load) user input -----
$userInput = Get-UserInput -Config $loadedConfig -NoConfirm:$NoConfirm

if ($null -eq $userInput) {
    Write-Host ""
    Write-Host "Operation cancelled by user. No deployment was executed." -ForegroundColor Yellow
    return
}

# ----- Optional: save current run's inputs as a reusable config -----
if (-not [string]::IsNullOrWhiteSpace($SaveConfig)) {
    try {
        Save-DeploymentConfig -UserInput $userInput -Path $SaveConfig
    }
    catch {
        Write-Host "WARNING: Failed to save config to '$SaveConfig': $_" -ForegroundColor Yellow
    }
}

Write-Host ""
Write-Host "Confirmed. Generating standalone deployment script..." -ForegroundColor Green

# ----- Generate the standalone script -----
$templatePath    = Join-Path $PSScriptRoot 'Application_Script_Template_Automate.ps1'
$outputDirectory = Join-Path $PSScriptRoot 'Generated'

try {
    $generatedScript = New-StandaloneDeploymentScript `
        -TemplatePath    $templatePath `
        -OutputDirectory $outputDirectory `
        -UserInput       $userInput

    Write-Host "Standalone script saved to:" -ForegroundColor Green
    Write-Host "  $generatedScript" -ForegroundColor Green
    Write-Host ""
}
catch {
    Write-Host "Failed to generate standalone script: $_" -ForegroundColor Red
    Write-Host "Aborting deployment." -ForegroundColor Red
    return
}

# ----- Build & write the manifest -----
$manifest = New-DeploymentManifest `
    -UserInput           $userInput `
    -GeneratedScriptPath $generatedScript `
    -ConfigFilePath      $ConfigFile `
    -InputSource         $inputSource

$manifestPath = Write-DeploymentManifest `
    -Manifest            $manifest `
    -GeneratedScriptPath $generatedScript `
    -OutputDirectory     $outputDirectory

$rollingLogPath = Join-Path $outputDirectory 'manifest_log.jsonl'

# ----- Run-now decision -----
if ($NoConfirm) {
    $runNow = 'Y'
    Write-Host "[-NoConfirm] Running generated script automatically." -ForegroundColor DarkCyan
}
else {
    do {
        $runNow = Read-Host "Run the generated script now? (Y/N)"
    } while ($runNow -notmatch '^(Y|y|Yes|yes|N|n|No|no)$')
}

if ($runNow -match '^(Y|y|Yes|yes)$') {
    Write-Host "Executing generated script..." -ForegroundColor Green
    $execStart = Get-Date
    $exitCode  = 0
    try {
        & $generatedScript
        $exitCode = $LASTEXITCODE
        if ($null -eq $exitCode) { $exitCode = 0 }
    }
    catch {
        Write-Host "Generated script threw an exception: $_" -ForegroundColor Red
        $exitCode = -1
    }
    $execEnd  = Get-Date
    $duration = ($execEnd - $execStart).TotalSeconds

    Update-ManifestExecution `
        -ManifestPath     $manifestPath `
        -RollingLogPath   $rollingLogPath `
        -Executed         $true `
        -ExitCode         $exitCode `
        -DurationSeconds  $duration

    Write-Host ""
    Write-Host "Execution complete. Exit code: $exitCode (took $([math]::Round($duration,1))s)" -ForegroundColor Cyan
}
else {
    Update-ManifestExecution `
        -ManifestPath     $manifestPath `
        -RollingLogPath   $rollingLogPath `
        -Executed         $false

    Write-Host "Generated script saved but not executed. You can run it later from:" -ForegroundColor Yellow
    Write-Host "  $generatedScript" -ForegroundColor Yellow
}

##================================================
## MARK: Features to add
##================================================
<#
add dynamic comment creation
add optional run intunewin32 for full automation
Maybe add multiple JSON handling to create several pacakges at one
#>